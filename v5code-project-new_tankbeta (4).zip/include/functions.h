#include "motor_setup.h"

//conversion.....................................................

float circumference = 6.10 * M_PI;
float convertDis = (360 / circumference);

//flywheel..........................................................

void flyfull()    //shoot across feild
{
  FLY.spin(fwd,90,pct);
}

void flyclose()    //shoot from half feild 
{
  FLY.spin(fwd,66.5,pct);
}

void flyangle()   //shoot from close range
{
  FLY.spin(fwd,55,pct);
}


void flystop()    //stop flywheel
{
  FLY.spin(fwd,0,pct);
}

//pneuamtics..........................................................

void expansion ()
{

   expand1.set(true);    //shoot out pistion    

}

//pneuamtics..........................................................

void closeclamp ()
{
  expand1.set(false);   //retacts pistion  
}

void anglulardown()
{
  angular.set(false);   //retracts pistion
}

void anglularup()
{
  angular.set(true);   //shoots out pistion
}

void blockade()
{
  blocker.set(true);
  wait(0.5,seconds);
  blocker.set(false);
}
//inertial sensor set up........................................

void TankSpin ( float Y, float R)
{
  TLM.spin (fwd, Y + R, rpm);
  BLM.spin (fwd, Y + R, rpm);
  MLM.spin (fwd, Y + R, rpm);
  TRM.spin (fwd, Y - R, rpm);
  BRM.spin (fwd, Y - R, rpm);
  MRM.spin (fwd, Y - R, rpm);
}


//inertial........................................................... 

void turnRDeg( float degr, float rpm)
{
  while( INT .rotation (deg) - degr <=0)
  {
    TankSpin ( 0, rpm );
    wait (5.0, msec);
  }
  TankSpin (0, 0);
  INT.resetRotation();
}

void turnLDeg( float degr, float rpm)
{
  while( INT .rotation (deg) + degr <=0)
  {
    TankSpin ( 0, rpm );
    wait (5.0, msec);
  }
  TankSpin (0, 0);
  INT.resetRotation();
}

void driveintake( float inches, double speed)
{
  INTAKE.spin(forward,600,rpm);
  TankDrive.spinFor((inches * convertDis), degrees,speed,rpm, true);
  INTAKE.stop();
}

void driveintakeB( float inches, double speed)
{
  INTAKE.spin(reverse,600,rpm);
  TankDrive.spinFor((inches * convertDis), degrees,speed,rpm, true);
  INTAKE.stop();
} 

//drive functions....................................................

void drivefwd (float inches, double speed)    //drive foward
{
  TLM.spinFor((inches * convertDis), degrees, speed, rpm, false);
  BLM.spinFor((inches * convertDis), degrees, speed, rpm, false);
  MLM.spinFor((inches * convertDis), degrees, speed, rpm, false);
  TRM.spinFor((inches * convertDis), degrees, speed, rpm, false);
  BRM.spinFor((inches * convertDis), degrees, speed, rpm, false);
  MRM.spinFor((inches * convertDis), degrees, speed, rpm, true);
} 

void driveback (float inches, double speed)   //drive backwards
{
  TLM.spinFor(-(inches * convertDis), degrees, speed, rpm, false);
  BLM.spinFor(-(inches * convertDis), degrees, speed, rpm, false);
  MLM.spinFor(-(inches * convertDis), degrees, speed, rpm, false);
  TRM.spinFor(-(inches * convertDis), degrees, speed, rpm, false);
  BRM.spinFor(-(inches * convertDis), degrees, speed, rpm, false);
  MRM.spinFor(-(inches * convertDis), degrees, speed, rpm, true);
}

void turnleft (float inches, double speed)   //turn left
{
  TLM.spinFor(-(inches * convertDis), degrees, speed, rpm, false);
  BLM.spinFor(-(inches * convertDis), degrees, speed, rpm, false);
  MLM.spinFor(-(inches * convertDis), degrees, speed, rpm, false);
  TRM.spinFor((inches * convertDis), degrees, speed, rpm, false);
  BRM.spinFor((inches * convertDis), degrees, speed, rpm, false);
  MRM.spinFor((inches * convertDis), degrees, speed, rpm, true);
} 

void turnright (float inches, double speed)   //turn right
{
  TLM.spinFor((inches * convertDis), degrees, speed, rpm, false);
  BLM.spinFor((inches * convertDis), degrees, speed, rpm, false);
  MLM.spinFor((inches * convertDis), degrees, speed, rpm, false);
  TRM.spinFor(-(inches * convertDis), degrees, speed, rpm, false);
  BRM.spinFor(-(inches * convertDis), degrees, speed, rpm, false);
  MRM.spinFor(-(inches * convertDis), degrees, speed, rpm, true);
} 