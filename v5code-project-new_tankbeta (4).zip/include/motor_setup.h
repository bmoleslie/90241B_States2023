#include "vex.h"

vex::controller Cr=vex::controller();

//DRIVE TRAIN
motor TLM ( PORT20, ratio6_1, true);
motor BLM ( PORT12, ratio6_1, true);
motor MLM ( PORT18, ratio6_1, true);
motor TRM ( PORT13, ratio6_1, false);
motor BRM ( PORT2, ratio6_1, false);
motor MRM ( PORT7, ratio6_1, false);

//INTAKe
motor INTAKE (PORT5,  true);

//FLYWHEEL
motor FLY (PORT6, true);


//INERTIAL
inertial INT =inertial (PORT10);

//drive train motor group
motor_group TankDrive (TLM,BLM,MLM,TRM,BRM,MRM);
